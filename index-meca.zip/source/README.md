## Plantilla d'un manuscrit de Quarto

Açò és una plantilla de repositori per generar un manuscrit amb Quarto. El tutorial
que l'acompanya està en: [Quarto Manuscripts: RStudio](https://quarto.org/docs/manuscripts/authoring/rstudio.html)

